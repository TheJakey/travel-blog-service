package com.dungeon.blogrestservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogRestServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlogRestServiceApplication.class, args);
	}

}
